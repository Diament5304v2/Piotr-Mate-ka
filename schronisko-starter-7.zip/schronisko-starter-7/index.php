<?php
$psy = [
    ['imie' => 'Reksio', 'wiek' => 3,  'rozmiar' => 'duzy'],
    ['imie' => 'Pusia',  'wiek' => 11, 'rozmiar' => 'maly'],
    ['imie' => 'Bary',   'wiek' => 7,  'rozmiar' => 'duzy'],
    ['imie' => 'Kropka', 'wiek' => 1,  'rozmiar' => 'maly'],
    ['imie' => 'Szarik', 'wiek' => 12, 'rozmiar' => 'duzy'],
    ['imie' => 'Fafik',  'wiek' => 5,  'rozmiar' => 'duzy'],
];

$blad = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $imie    = isset($_POST['imie'])    ? $_POST['imie']    : '';
    $wiek    = isset($_POST['wiek'])    ? $_POST['wiek']    : '';
    $rozmiar = isset($_POST['rozmiar']) ? $_POST['rozmiar'] : '';

    if ($imie === '') {
        $blad = 'Podaj imię psa.';
    } elseif (!ctype_digit($wiek) || (int) $wiek <= 0 || $wiek >= 20) {//Błąd 7, 8 wiek był mniejszy od zera i nie było warunku co do 20
        $blad = 'Wiek to liczba całkowita od 0 do 20.';
    } elseif ($rozmiar !== 'maly' && $rozmiar !== 'duzy') {
        $blad = 'Wybierz rozmiar z listy.';
    }

    $psy[] = ['imie' => $imie, 'wiek' => (int) $wiek, 'rozmiar' => $rozmiar];//Błąd 8
}

if ($_GET['rozmiar'] != '') {// Błąd 6
    $wybrane = [];
    foreach ($psy as $pies) {
        if ($pies['rozmiar'] === 'maly') {
            $wybrane[] = $pies;
        }
    }
} else {
    $wybrane = $psy;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Schronisko Łapka</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Schronisko Łapka</h1>
    </header>
    <nav>
        <a href="index.php">Wszystkie</a>
        <a href="index.php?rozmiar=maly">Małe</a>
        <a herf="index.php?rozmiar=duzy">Duże</a>
    </nav>
    <main>
        <table>
            <thead>
                <tr><th>Imię</th><th>Wiek</th><th>Rozmiar</th></tr>
            </thead>
            <tbody>
<?php foreach ($wybrane as $pies): ?>
                <tr<?php if ($pies['wiek'] >= 10) echo ' class="senior"'; ?>>
                    <td><?php echo $pies['imie']; ?></td>
                    <td><?php echo $pies['wiek']; ?></td>
                    <td><?php echo $pies['rozmiar'] === 'maly' ? 'mały' : 'duży'; ?></td>
                </tr>
<?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="3">Psów w tabeli: <?php echo count($wybrane); ?></td></tr>
            </tfoot>
        </table>
    </main>
    <aside>
        <h2>Przyjmij psa do schroniska</h2>
<?php if ($blad !== ''): 
        echo "<p class='blad'> . $blad </p>"; //Błąd 4, 5
    endif; ?>
        <form method="post">
            <label>Imię <input type="text" name="imie"></label>
            <label>Wiek <input type="number" name="lata" min=0 max=20></label><!-- Błąd 2, 3 -->
            <label>Rozmiar
                <select name="rozmiar">
                    <option value="maly">mały</option>
                    <option value="duzy">duży</option>
                </select>
            </label>
            <button type="submit">Dodaj</button>
        </form>
    </aside>
    <footer>
        <p>Stronę wykonał: nazwisko_imie</p>
    </footer>
</body>
</html>
