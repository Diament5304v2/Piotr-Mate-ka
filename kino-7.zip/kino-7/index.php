<?php
function cenaBiletu($rodzaj, $dzien)
{
    if ($rodzaj === 'ulgowy') {
        $cena = 18;
    } else {
        $cena = 25;
    }
    if ($dzien === 'wtorek') {
        $cena = $cena - 5;
    }
    return $cena;
}

$dni = [
    'poniedzialek' => 'poniedziałek',
    'wtorek'       => 'wtorek',
    'sroda'        => 'środa',
    'czwartek'     => 'czwartek',
    'piatek'       => 'piątek',
    'sobota'       => 'sobota',
    'niedziela'    => 'niedziela',
];

$komunikat = '';
$wiersze = [];
$suma = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $normalne = isset($_POST['normalne']) ? $_POST['normalne'] : '';
    $ulgowe   = isset($_POST['ulgowe'])   ? $_POST['ulgowe']   : '';
    $dzien    = isset($_POST['dzien'])    ? $_POST['dzien']    : '';

    if (!ctype_digit($normalne) || !ctype_digit($ulgowe)) {
        $komunikat = 'Liczba biletów musi być liczbą całkowitą.';
    } elseif ((int) $normalne + (int) $ulgowe === 0) {
        $komunikat = 'Wybierz co najmniej jeden bilet.';
    } elseif ((int) $normalne + (int) $ulgowe > 10) {
        $komunikat = 'Jednorazowo można kupić najwyżej 10 biletów.';
    } elseif (!isset($dni[$dzien])) {
        $komunikat = 'Wybierz dzień z listy.';
    } else {
        foreach (['normalny' => (int) $normalne, 'ulgowy' => (int) $ulgowe] as $rodzaj => $liczba) {
            if ($liczba > 0) {
                $cena = cenaBiletu($rodzaj, $dzien);
                $wiersze[] = ['rodzaj' => $rodzaj, 'liczba' => $liczba, 'cena' => $cena];
                $suma = $suma + $liczba * $cena;
            }
        }
        if ((int) $normalne + (int) $ulgowe >= 6) {
            $suma = $suma - 15;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Kino Zorza</title>
</head>
<body>
    <h1>Kino Zorza — kasa</h1>
    <form method="post">
        <label>Bilety normalne <input type="number" name="normalne" value="0"></label>
        <label>Bilety ulgowe <input type="number" name="ulgowe" value="0"></label>
        <label>Dzień
            <select name="dzien">
<?php foreach ($dni as $klucz => $nazwa): ?>
                <option value="<?php echo $klucz; ?>"><?php echo $nazwa; ?></option>
<?php endforeach; ?>
            </select>
        </label>
        <button type="submit">Policz</button>
    </form>
<?php if ($komunikat !== ''): ?>
    <p><?php echo $komunikat; ?></p>
<?php endif; ?>
<?php if (count($wiersze) > 0): ?>
    <table>
        <tr><th>Bilet</th><th>Liczba</th><th>Cena</th><th>Razem</th></tr>
<?php foreach ($wiersze as $w): ?>
        <tr>
            <td><?php echo $w['rodzaj']; ?></td>
            <td><?php echo $w['liczba']; ?></td>
            <td><?php echo $w['cena']; ?> zł</td>
            <td><?php echo $w['liczba'] * $w['cena']; ?> zł</td>
        </tr>
<?php endforeach; ?>
    </table>
    <p>Do zapłaty: <?php echo $suma; ?> zł</p>
<?php endif; ?>
</body>
</html>
